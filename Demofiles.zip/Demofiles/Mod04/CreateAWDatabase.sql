USE master
GO
IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'aw')
CREATE DATABASE aw
GO

USE aw
GO
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'vEmployee')
SELECT BusinessEntityID as ID,FirstName,LastName,JobTitle,PhoneNumber,EmailAddress INTO aw.dbo.vEmployee FROM AdventureWorks2019.HumanResources.vEmployee
GO

