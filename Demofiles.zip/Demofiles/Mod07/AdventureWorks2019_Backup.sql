--  Backup AdventureWorks2019 database using Full and Log backups

USE master
GO

ALTER DATABASE AdventureWorks2019 SET RECOVERY FULL WITH NO_WAIT
GO

USE AdventureWorks2019
GO

BACKUP DATABASE AdventureWorks2019
TO DISK = 'C:\Classfiles\aw2019.bak'
WITH FORMAT,
MEDIANAME = 'aw2019Backups',
NAME = 'AdventureWorks2019 Full Backup'
GO

BACKUP LOG AdventureWorks2019
TO DISK = 'C:\Classfiles\aw2019.bak'
WITH NAME = 'AdventureWorks2019 Log Backup'
GO
