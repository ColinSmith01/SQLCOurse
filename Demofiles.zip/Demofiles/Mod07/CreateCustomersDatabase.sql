-- Create the Customers database on MIA-SQL\SQL2
-- This database will use an encrypted backup that will be restored to MIA-SQL
-- Verify the instance name is SQL2 before proceeding. (e.g. SELECT @@servicename)

USE master
GO
IF NOT EXISTS (SELECT * FROM sys.servers WHERE name = 'MIA-SQL') 
EXEC master.dbo.sp_addlinkedserver @server = 'MIA-SQL', @srvproduct = 'SQL Server'
GO

IF EXISTS(SELECT * FROM sys.databases WHERE name = 'Customers') DROP DATABASE Customers
GO
CREATE DATABASE Customers
GO

USE Customers
GO
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Customer') DROP TABLE dbo.Customer
SELECT * INTO Customers.dbo.Customer FROM [MIA-SQL].AdventureWorks2019.Sales.Customer
GO


