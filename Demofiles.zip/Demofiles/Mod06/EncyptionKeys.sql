--Create a database master key 
USE master
GO
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa$$w0rd'
GO
SELECT * FROM sys.symmetric_keys

--Backup the database master key
OPEN MASTER KEY DECRYPTION BY PASSWORD = 'Pa$$w0rd'
BACKUP MASTER KEY TO FILE = 'C:\Classfiles\master.key'
ENCRYPTION BY PASSWORD = 'Pa$$w0rd'
GO

--Create a certificate
CREATE CERTIFICATE AWCert
WITH SUBJECT = 'AdventureWorks2019 Certificate'

--Backup the certificate and its private key
BACKUP CERTIFICATE AWCert 
TO FILE = 'C:\Classfiles\AWCert.cer'
WITH PRIVATE KEY (file = 'C:\Classfiles\AWCert.pvk' ,
encryption by password = 'Pa$$w0rd')
GO



