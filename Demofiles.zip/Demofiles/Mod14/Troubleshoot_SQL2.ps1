## Stop SQL Server service for SQL2 Instance
## Rename the master database while it is stopped

## 1. Stop SQL Server Service
Stop-Service -Name "MSSQL`$SQL2" -Force

## 2. Rename the master database
$DatabasePath = "C:\Program Files\Microsoft SQL Server\MSSQL15.SQL2\MSSQL\DATA\"
Set-Location -Path $DatabasePath
Move-Item -Path master.mdf -Destination master.mdf.backup

## 3. Generate Windows Event System Log by trying, but failing to start SQL2 instance
Start-Service -Name "MSSQL`$SQL2" 

## 4. Open the Event Viewer and check the system log for an error related to the SQL2 instance
## You may also run the command below to view the last 5 events in the System log
Get-EventLog -LogName System -Newest 5 | Format-List TimeGenerated, EntryType, Source, Message

## 5. Rename the master database file for the SQL2 instance and restart the service
Set-Location -Path $DatabasePath
Move-Item -Path master.mdf.backup -Destination master.mdf
Start-Service -Name "MSSQL`$SQL2" 

## 6. Verify that the System Event Log shows that the SQL2 instance "entered the running state" 
Get-EventLog -LogName System -Newest 5 | Format-List TimeGenerated, EntryType, Source, Message

