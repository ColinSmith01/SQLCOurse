## Create a Windows Logins for the Dev group and two of its users
## One of the users will be able to login, the other will not.  Diagnose the issue and solve it.

## 1. Create Windows group and users
$Password = ConvertTo-SecureString "Password1" -AsPlainText -Force
New-ADGroup -Name "Developers" -SamAccountName Developers -GroupCategory Security -GroupScope Global -DisplayName "Developers"
New-ADUser -Name "DevUser1" -Accountpassword $Password -Enabled $True
New-ADUser -Name "DevUser2" -Accountpassword $Password -Enabled $True
Add-ADGroupMember -Identity "Server Operators" -Members DevUser1, DevUser2
Add-ADGroupMember -Identity Developers -Members DevUser1, DevUser2
Get-ADGroupMember -Identity Developers

## 2. Create Login for MIA-SQL
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\Databases\AdventureWorks2019
$ServerInstance = "MIA-SQL"
Add-SqlLogin -ServerInstance $ServerInstance -LoginName "CONTOSO\Developers" -LoginType WindowsGroup -GrantConnectSQL
Add-SqlLogin -ServerInstance $ServerInstance -LoginName "CONTOSO\DevUser2" -LoginType WindowsUser
Invoke-Sqlcmd -InputFile C:\Classfiles\Demofiles\Mod14\CreateDBUser.sql -ServerInstance $ServerInstance 



