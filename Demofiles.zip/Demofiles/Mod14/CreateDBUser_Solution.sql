-- The problem with the DevUser2 login can be fixed in one of two ways.
-- 1. By enabling the login and granting it access to the instance.  The existing settings deny login access.
USE master
GO
GRANT CONNECT SQL TO [CONTOSO\DevUser2]
GO
ALTER LOGIN [CONTOSO\DevUser2] ENABLE
GO

-- 2. By deleting the login.  This will force DevUser2 to use their group access via CONTOSO\Developers
USE master
GO
DROP LOGIN [CONTOSO\DevUser2]
GO

