-- Create database user account for Contoso\Developers

USE AdventureWorks2019
GO
CREATE USER [CONTOSO\Developers] FOR LOGIN [CONTOSO\Developers]
GO
ALTER ROLE db_datareader ADD MEMBER [CONTOSO\Developers]
GO
