### Add SQL Server logins, role members and users

## - Step 1 - Create a login account 
## - It will have the name SQLLogin1 and a password of Password1
## - It will belong to the dbcreator role
## $MIASQL1 = New-Object ('Microsoft.SqlServer.Management.Smo.Server') "MIA-SQL"
Import-Module SqlServer
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\
$ServerName = "MIA-SQL"
$MIASQL = Get-SqlInstance -ServerInstance $ServerName
$DBCreatorRole = $MIASQL.Roles | Where {$_.Name -eq "dbcreator"}
$LoginName = "SQLLogin1"
$LoginType = "SqlLogin"
$Password = ConvertTo-SecureString -String "Password1" -AsPlainText -Force
$PSCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $LoginName, $Password
Add-SqlLogin -LoginName $LoginName -LoginType $LoginType -Enable -GrantConnectSQL -LoginPSCredential $PSCredential   
$DBCreatorRole.AddMember($LoginName)
# Save changes and verify that the SQLLogin1 account was created
$MIASQL.Alter()
Get-SQLLogin -LoginName $LoginName -Path SQLSERVER:\SQL\MIA-SQL\Default\Logins

## - Step 2 - Create a user account in AdventureWorks2019
## - Review the input file before running the Invoke-Sqlcmd cmdlet
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\Databases\AdventureWorks2019
Invoke-Sqlcmd -InputFile C:\Classfiles\Demofiles\Mod11\CreateUser.sql -ServerInstance $ServerName 
$MIASQL.Alter()

# Test the SQL Login "SQLLogin1" using the password "Password1".  
# It should be able to connect to MIA-SQL, use the AdventureWorks2019 database and create new databases.