### Backup and restore a database

## Variables
$ServerName = "MIA-SQL"
$DatabaseName = "AdventureWorksDW2019"
$BackupFile = "C:\Backup\" + $DatabaseName + ".bak"

## - Step 1 - Backup the AdventureWorksDW2019 database
Import-Module SqlServer
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\Databases\
Backup-SqlDatabase -ServerInstance "MIA-SQL" -Database $DatabaseName -BackupFile $BackupFile -CompressionOption "On"
## Verify that the backup file was created in the C:\Backup folder

## - Step 2 - Delete the AdventureWorksDW2019 database
Set-Location SQLSERVER:\SQL\MIA-SQL\Default\Databases\
Get-ChildItem
Remove-Item $DatabaseName
Get-ChildItem
## Verify in SSMS that the AdventureWorksDW2019 database has been deleted

## - Step 3 - Restore the AdventureWorksDW2019 database
Restore-SqlDatabase -ServerInstance $ServerName -Database $DatabaseName -BackupFile $BackupFile
Get-ChildItem
## Verify in SSMS that the AdventureWorksDW2019 database has been restored
