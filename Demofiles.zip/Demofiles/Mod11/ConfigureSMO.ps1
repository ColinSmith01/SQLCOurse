### Modify Database and Server features using PowerShell

## - Step 1 - Modify the database compatibility level
Import-Module SqlServer
Set-Location SQLSERVER:\SQL\localhost\Default\Databases
$AW = Get-SqlDatabase AdventureWorks2019
Set-Location C:\Classfiles
$AW
$AW | Get-Member 
$AW.CompatibilityLevel = "Version150"
$AW.Alter()
$AW

## - Step 2 - Modify the Instance's authentication mode
Set-Location SQLSERVER:\SQL\
$MIASQL = Get-SqlInstance -ServerInstance "MIA-SQL"
$MIASQL.LoginMode
$MIASQL.LoginMode = "Integrated"
$MIASQL.Alter()
Restart-Service MSSQLSERVER -Force
Restart-Service SQLSERVERAGENT -Force

## - Note:  This can also be done with the Set-SqlAuthenticationMode cmdlet