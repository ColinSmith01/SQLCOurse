USE [AdventureWorks2019]
GO
CREATE USER [SQLLogin1] FOR LOGIN [SQLLogin1]
GO
USE [AdventureWorks2019]
GO
ALTER ROLE [db_owner] ADD MEMBER [SQLLogin1]
GO
