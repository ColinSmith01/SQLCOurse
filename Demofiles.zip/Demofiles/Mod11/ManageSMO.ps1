### Manage SQL Server Management Objects (SMOs) using PowerShell 
### Run the commands one line at a time

### 1. Try commonly used PowerShell cmdlets
Get-Help Get-Command
help gcm
Get-Help Import-Module
Get-Command Get-*
Get-Command *-Module
Get-Command -Module SQLServer
(gcm -module sqlserver).count

### 2. Work with the SqlServer Module
Import-Module SqlServer
Get-PSDrive -PSProvider SqlServer
Set-Location SQLSERVER:\
CD SQL\
Get-ChildItem
CD MIA-SQL
Get-ChildItem
CD Default
Get-ChildItem
CD Databases
Get-ChildItem
# Remove the AdventureWorksDW2019 database
Remove-Item AdventureWorksDW2019
Get-ChildItem
Get-Location
Set-Location C:\Classfiles

# Open SSMS to verify that the AdventureWorksDW2019 database has been deleted.
