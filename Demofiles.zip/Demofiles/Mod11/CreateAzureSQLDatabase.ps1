### Create an Azure SQL Database that is accessible from the Azure Portal
### Change the name of the server before proceeding
### Provide your existing Azure login credentials when prompted
### Provide new Azure SQL Server login credentials when prompted

# Variables
$server = "srv20220601"
$rg = "rg1"

Connect-AzAccount
New-AzResourceGroup -Name rg1 -Location eastus
New-AzSqlServer -ResourceGroupName $rg -ServerName $server -Location eastus -SqlAdministratorCredentials (Get-Credential) 
New-AzSqlServerFirewallRule -ResourceGroupName $rg -ServerName $server -AllowAllAzureIPs
New-AzSqlDatabase  -ResourceGroupName $rg -ServerName $server -DatabaseName db1 -SampleName "AdventureWorksLT"

# Run the command below to delete all resources when you are finished
# Remove-AzResourceGroup -RsourceGroup $rg 

### When complete, verify the database was created correctly by accessing it from the Azure Portal